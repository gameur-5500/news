from turtle import *
color('blue', 'black')
begin_fill()
while True:
    forward(100)
    left(97)
    if abs(pos()) < 2:
        break
end_fill()
done()