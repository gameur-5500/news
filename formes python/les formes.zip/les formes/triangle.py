from turtle import *
color('blue', 'black')
begin_fill()
while True:
    forward(150)
    left(1200)
    if abs(pos()) < 2:
        break
end_fill()
done()