from turtle import *
color('blue', 'white')
begin_fill()
while True:
    forward(100)
    left(300)
    if abs(pos()) < 2:
        break
end_fill()
done()